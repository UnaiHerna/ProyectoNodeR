package app;

import hex.genmodel.easy.RowData;
import hex.genmodel.easy.EasyPredictModelWrapper;
import hex.genmodel.easy.exception.PredictException;
import hex.genmodel.easy.prediction.*;
import hex.genmodel.MojoModel;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws Exception {

        // Los argumentos se reciben como String en CMD
        double age = Double.parseDouble(args[0]);
        double race = Double.parseDouble(args[1]);
        double psa = Double.parseDouble(args[2]);
        double gleason = Double.parseDouble(args[3]);

        h2o_function(age, race, psa, gleason);
    }

    private static void h2o_function(double age, double race, double psa, double gleason) throws IOException, PredictException {
        EasyPredictModelWrapper model = new EasyPredictModelWrapper(MojoModel.load("C:/Users/UnaiHernandezIzcue/ProyectosJS/ProyectoNodeR/Api/files/java/h2o_ai/src/files/GBM_model_R_1726066137038_1.zip"));

        RowData row = new RowData();
        row.put("AGE", age);
        row.put("RACE", race);
        row.put("PSA", psa);
        row.put("GLEASON", gleason);

        BinomialModelPrediction p = model.predictBinomial(row);
        System.out.println("{");
        System.out.println("  \"clase\": " + p.label + ",");
        
        for (int i = 0; i < p.classProbabilities.length; i++) {
            if (i > 0) {
                System.out.print(", ");
            }
            System.out.print("\"prob" + i + "\": " + p.classProbabilities[i]);
        }
        System.out.println("}");
    }
}
